using System;
using Godot;
using Sfs3.Client;

public abstract partial class BaseController : Control
{
    private GlobalManager global;

    protected SmartFox sfs;

    public override void _Ready()
    {
        global = (GlobalManager)GetNode("/root/GlobalManager");
    }

    public override void _ExitTree()
    {
        RemoveSmartFoxListeners();
    }

    public GlobalManager Global => global;

    public abstract void RemoveSmartFoxListeners();
}
