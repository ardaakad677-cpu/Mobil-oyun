using Godot;
using System;

public partial class Hud : CanvasLayer
{
	[Export]
	private Button muteButton;
	[Export]
	private Label nameLabel;

	[Signal]
    public delegate void MuteEventHandler();

	[Signal]
    public delegate void LogoutEventHandler();

	[Signal]
    public delegate void ToggleServerStreamEventHandler();
	
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}

	public void SetUserName(string name)
	{
		nameLabel.Text = name;
	}

	public void ResetMuteButton()
	{
		muteButton.SetPressedNoSignal(false);
	}

	private void OnMuteButtonPressed(bool isPressed)
	{
		EmitSignal(SignalName.Mute, isPressed);
	}

	private void OnLogoutButtonPressed()
	{
		EmitSignal(SignalName.Logout);
	}
}
