using Godot;
using System;

public partial class Avatar : CharacterBody3D
{
	private Sprite3D talkIcon;
	private Sprite3D muteIcon;
	private Label nameLabel;

	AudioStreamPlayer3D asp;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		nameLabel = GetNode<Label>("SubViewport/Label");
		talkIcon = GetNode<Sprite3D>("TalkIcon");
		muteIcon = GetNode<Sprite3D>("MuteIcon");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}

	public void SetLabel(string name)
	{
		nameLabel.Text = name;
	}

	public void AddAudioStreamPlayer(AudioStreamPlayer3D asp, bool isMuted)
	{
		asp.Name = "AudioStreamPlayer";
        AddChild(asp);

		asp.Translate(new Vector3(0, 0.5f, 0));
		asp.EmissionAngleEnabled = true;

		this.asp = asp;

		SetMuted(isMuted);
	}

	public void RemoveAudioStreamPlayer()
	{
		RemoveChild(asp);

		talkIcon.Visible = false;
		muteIcon.Visible = false;
	}

	public void SetMuted(bool isMuted)
	{
		talkIcon.Visible = !isMuted;
		muteIcon.Visible = isMuted;
	}
}
